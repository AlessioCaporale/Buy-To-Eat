-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: progettopw
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prodotti`
--

DROP TABLE IF EXISTS `prodotti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prodotti` (
  `codprodotto` int(11) NOT NULL AUTO_INCREMENT,
  `descr` varchar(120) NOT NULL,
  `pre` decimal(4,2) NOT NULL,
  `um` varchar(3) NOT NULL,
  `peso` decimal(4,2) NOT NULL,
  `disponibilita` varchar(10) NOT NULL,
  `codCategoria` int(11) NOT NULL,
  `immagine` varchar(50) DEFAULT NULL,
  `codiva` varchar(3) NOT NULL,
  `desccompl` varchar(255) DEFAULT NULL,
  `quant` int(11) NOT NULL,
  `approvato` tinyint(1) NOT NULL,
  `fornitore` varchar(100) NOT NULL,
  PRIMARY KEY (`codprodotto`),
  KEY `codcatwegoria_idx` (`codCategoria`),
  KEY `codiva_idx` (`codiva`),
  KEY `fornitori_idx` (`fornitore`),
  CONSTRAINT `codcategoria` FOREIGN KEY (`codCategoria`) REFERENCES `categorie` (`codCategoria`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `codiva` FOREIGN KEY (`codiva`) REFERENCES `iva` (`codiva`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fornitori` FOREIGN KEY (`fornitore`) REFERENCES `fornitori` (`email`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prodotti`
--

LOCK TABLES `prodotti` WRITE;
/*!40000 ALTER TABLE `prodotti` DISABLE KEYS */;
INSERT INTO `prodotti` VALUES (1,'Carmasciano',10.00,'Kg',2.00,'Media',1,'carmasciano.jpg','22','',5,1,'azienda1@info.it'),(2,'Cacio',12.00,'Kg',3.00,'Media',1,'cacio.jpg','22','',2,1,'azienda1@info.it'),(4,'Pecorino',15.00,'Kg',4.00,'Media',1,'pecorino.jpg','22','',2,1,'azienda1@info.it'),(5,'Bocconcini',11.50,'Kg',0.50,'Bassa',2,'bocconcini.jpg','22','',4,1,'azienda1@info.it'),(6,'Mozzarelle',10.00,'Kg',0.75,'0',2,'mozzarelle.jpg','22','',7,1,'azienda1@info.it'),(7,'Ricotta',9.00,'Kg',0.50,'Bassa',2,'ricotta.jpg','22','',5,1,'azienda1@info.it'),(8,'Panini',1.50,'Kg',0.30,'Media',3,'panini.jpg','22','',5,1,'azienda1@info.it'),(9,'Pagnotta',1.80,'Kg',1.00,'Media',3,'panee.jpg','22','',7,1,'azienda1@info.it'),(10,'Sfilatini',1.50,'Kg',0.50,'Media',3,'sfilatino.jpg','22','',10,1,'azienda1@info.it'),(11,'Fusilli',5.00,'Kg',0.75,'Media',4,'fusilli.jpg','22','',10,1,'azienda1@info.it'),(12,'Orecchiette',7.00,'Kg',0.75,'Media',4,'orecchiette.gif','22','',11,1,'azienda1@info.it'),(13,'Cicatelli',6.00,'Kg',0.75,'Media',4,'cicatelli.jpg','22','',12,1,'azienda1@info.it'),(14,'Ciliegie',15.00,'Kg',1.00,'Bassa',5,'ciliegie.jpg','22','',15,1,'azienda1@info.it'),(15,'Lamponi',15.00,'Kg',1.00,'Bassa',5,'lamponi.jpg','22','',15,1,'azienda1@info.it'),(16,'Mirtilli',15.00,'Kg',1.00,'Bassa',5,'mirtilli.jpg','22','',15,1,'azienda1@info.it'),(17,'Fiano',35.00,'Lt',0.75,'Media',6,'fiano.jpg','22','',38,1,'azienda1@info.it'),(18,'Rosè',40.00,'Lt',0.75,'Media',6,'rose.png','22','',40,1,'azienda1@info.it'),(19,'Aglianico',60.00,'Lt',0.75,'Media',6,'rosso.jpg','22','',36,1,'azienda1@info.it'),(20,'Olio Extravergine',9.00,'Lt',1.00,'Alta',7,'olioo.jpg','22','',50,1,'azienda1@info.it'),(21,'Grano Duro',10.00,'Kg',1.00,'Media',8,'','22','',30,1,'azienda1@info.it'),(22,'Grano Tenero',12.00,'Kg',1.00,'Media',8,'','22','',29,1,'azienda1@info.it'),(23,'Tipo 00',11.00,'Kg',1.00,'Media',8,'','22','',30,1,'azienda1@info.it'),(24,'ckvbfol',11.00,'hj',12.00,'Bassa',3,'','22','dksgdiufkh',100,0,'azienda1@info.it'),(25,'casa',12.00,'kg',12.00,'Media',8,'','22','gfuigdkb',100,0,'azienda1@info.it'),(26,'casa',12.00,'kg',12.00,'Media',5,'','22','',200,0,'azienda1@info.it');
/*!40000 ALTER TABLE `prodotti` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-16 12:05:55
