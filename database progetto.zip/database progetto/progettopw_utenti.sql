-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: progettopw
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `utenti`
--

DROP TABLE IF EXISTS `utenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `utenti` (
  `email` varchar(100) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `cognome` varchar(70) NOT NULL,
  `nome` varchar(70) NOT NULL,
  `codfis` varchar(16) NOT NULL,
  `datanascita` varchar(11) DEFAULT NULL,
  `accesso` int(11) DEFAULT NULL,
  `tipocarta` varchar(1) DEFAULT NULL,
  `nrcarta` varchar(16) DEFAULT NULL,
  `newsletter` tinyint(1) DEFAULT NULL,
  `ultimor` int(11) DEFAULT NULL,
  `flag` tinyint(1) DEFAULT NULL,
  `tipo` varchar(2) DEFAULT NULL,
  `elimina` tinyint(1) DEFAULT NULL,
  `bloccato` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`email`),
  UNIQUE KEY `codfis_UNIQUE` (`codfis`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utenti`
--

LOCK TABLES `utenti` WRITE;
/*!40000 ALTER TABLE `utenti` DISABLE KEYS */;
INSERT INTO `utenti` VALUES ('asdf@dsait','asdfghjkl','asd','asd','SDASDA80A01I061Y','1980-01-01',2,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL),('assunta@gmail.com','assunta','Sgambati','Assunta','SGMSNT95C68A509B',' 28/03/1995',1,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL),('caggiano.gianluca.96@hotmail.it','password','Cagggiano','Gianluca','CGGGLC96C14A783I','1996-04-03',NULL,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL),('carlorossi@carlorossi.it','dsabkbfdlgbfpn','Carlo','Ross','CRLRSS80A01I061E','1980-01-01',1,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL),('carloverdi@verdi.it','carlocbverdi','Verdi','CArlo','VRDCRL82A01I061O','1982-01-01',1,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL),('carm@live,it','66casa','rigillo','carmela','rglcrm66g07a169t','1966-02-07',NULL,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL),('casa@casa.it','123456789','Casa','Casa','CSACSA17S15I163O',' 15/11/2017',1,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL),('francescocena02@gmail.com','3333','Galante','Francesco','GLNFRN02B05A399E','2002-05-02',NULL,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL),('giuseppe.galante@gmail.com','12345','Galante','Giuseppe','GLNGPP96E07A389E','1996-05-07',19,NULL,NULL,NULL,NULL,NULL,'ut',0,NULL),('giuseppegalante@gmail.com','123456789','Galante','Giuseppe','GLNGPP96E07A399E','07/05/1996',3,NULL,NULL,NULL,NULL,NULL,'ut',0,NULL),('mariorossi@prova.it','mariorossi','Rossi','Mario','RSSMRA01A01I061Y','2001-01-01',0,NULL,NULL,NULL,NULL,NULL,'ut',NULL,NULL);
/*!40000 ALTER TABLE `utenti` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-16 12:05:55
