package registrazione;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/regaz")
public class regaz extends HttpServlet 
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		String url="jdbc:mysql:///progettopw?autuReconect=true&useSSL=false";
		Connection connect,connect1;
		String query,query1;
		PreparedStatement stmt,stmt1;
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String email,password,nomeazienda,stato,regione,provincia,comune,indirizzo,cap,piva,cdf;
		String vere,veriva,vericod;
		int flag=0;
		email=req.getParameter("emailaz");
		password=req.getParameter("passaz");
		nomeazienda=req.getParameter("azienda");
		stato=req.getParameter("stato");
		comune=req.getParameter("comune");
		provincia=req.getParameter("provincia");
		indirizzo=req.getParameter("indirizzo");
		cdf=req.getParameter("codfisaz");
		piva=req.getParameter("piva");
		cap=req.getParameter("cap");
		try{
			query1="SELECT email,piva,codfis FROM fornitori";
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			connect1=DriverManager.getConnection(url,"root","123456789");
			stmt1=connect1.prepareStatement(query1);
			ResultSet ris1=stmt1.executeQuery();
			while(ris1.next())
			{
				
				vere=ris1.getString("email");
				veriva=ris1.getString("piva");
				vericod=ris1.getString("codfis");
				if(email.equals(vere) || piva.equals(veriva) || piva.equals(vericod))
				{
					
					
					flag=1;
					//res.forward("Esiste.jsp?z=1");
					req.getRequestDispatcher("Esiste.jsp?z=1").forward(req, res);
					
				}
				
			}
			stmt1.close();
			connect1.close();

			
			
		}catch(SQLException ex)
		{
			System.err.println("SQLException: "+ex.getMessage());
		}
		
if(flag==0)
{

		
		try{
			query="INSERT INTO fornitori(email,pass,nomeaz,indirizzo,codfis,piva,stato,comune,provincia,cap,elimina,bloccato) VALUES (?,?,?,?,?,?,?,?,?,?,?,?);";
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			connect=DriverManager.getConnection(url,"root","123456789");
			stmt=connect.prepareStatement(query);
			stmt.setString(1, email);
			stmt.setString(2, password);
			stmt.setString(3, nomeazienda);
			stmt.setString(4, indirizzo);
			stmt.setString(5, cdf);
			stmt.setString(6, piva);
			stmt.setString(7, stato);
            stmt.setString(8, comune);
            stmt.setString(9, provincia);
            stmt.setString(10, cap);
            stmt.setString(11, "0");
            stmt.setString(12, "0");
			stmt.executeUpdate();
			stmt.close();
			connect.close();
			
		}catch(SQLException ex)
		{
			System.err.println("SQLException: "+ex.getMessage());
		}
		
		HttpSession session = req.getSession();
		session.setAttribute("emailaz",email);
		session.setAttribute("nomeaz", nomeazienda);
		session.setAttribute("pass", password);
		session.setAttribute("loggato","az");
		res.sendRedirect("Index.jsp");
	}


}
}

