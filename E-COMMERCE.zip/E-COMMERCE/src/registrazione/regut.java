package registrazione;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/regut")
public class regut extends HttpServlet 
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		String url="jdbc:mysql:///progettopw?autuReconect=true&useSSL=false";
		Connection connect,connect1;
		String query,query1;
		PreparedStatement stmt,stmt1;
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String email,password,cognome,nome,stato,regione,provincia,comune,indirizzo,cap,cdf,datanascita;
		String vere,vercdf;
		int flag=0;

		email=req.getParameter("email");
		password=req.getParameter("pass");
		cognome=req.getParameter("cognome");
		nome=req.getParameter("nome");
		stato=req.getParameter("stato");
		indirizzo=req.getParameter("indirizzo");
		comune=req.getParameter("comune");
		
		cdf=req.getParameter("codfis");
		datanascita=req.getParameter("datanascita");
		provincia=req.getParameter("provincia");
		cap=req.getParameter("cap");

		try{
			query1="SELECT email,codfis FROM utenti";
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			connect1=DriverManager.getConnection(url,"root","123456789");
			stmt1=connect1.prepareStatement(query1);
			ResultSet ris1=stmt1.executeQuery();
			while(ris1.next())
			{
				
				vere=ris1.getString("email");
				vercdf=ris1.getString("codfis");
				if(email.equals(vere) || cdf.equals(vercdf))
				{
					
					
					flag=1;
					//res.sendRedirect("Esiste.jsp?z=0");
					req.getRequestDispatcher("Esiste.jsp?z=0").forward(req, res);
					
				}
				
			}
			stmt1.close();
			connect1.close();

			
			
		}catch(SQLException ex)
		{
			System.err.println("SQLException1: "+ex.getMessage());
		}
		
if(flag==0)
{


		
		
		
		try{
			query="INSERT INTO utenti (email, pass, cognome, nome,codfis, datanascita, tipo,accesso) VALUES (?,?,?,?,?,?,?,1);";
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			connect=DriverManager.getConnection(url,"root","123456789");
			stmt=connect.prepareStatement(query);
			stmt.setString(1, email);
			stmt.setString(2, password);
			stmt.setString(3, cognome);
			stmt.setString(4, nome);
			stmt.setString(5, cdf);
			stmt.setString(6, datanascita);
			stmt.setString(7, "ut");
			stmt.executeUpdate();
			stmt.close();
			connect.close();
			
		}catch(SQLException ex)
		{
			System.err.println("SQLException2: "+ex.getMessage());
		}
		
		Connection connect2;
		String query2;
		PreparedStatement stmt2;
		
		try{
			query2="INSERT INTO datispedizione (Stato, Indirizzo, Comune, Provincia, cap,utente) VALUES (?,?,?,?,?,?);";
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			connect2=DriverManager.getConnection(url,"root","123456789");
			stmt2=connect2.prepareStatement(query2);
			stmt2.setString(1, stato);
			stmt2.setString(2, indirizzo);
			stmt2.setString(3, comune.toUpperCase());
			stmt2.setString(4, provincia);
			stmt2.setString(5, cap);
			stmt2.setString(6, email);
			stmt2.executeUpdate();
			stmt2.close();
			connect2.close();
			
		}catch(SQLException ex)
		{
			
			System.err.println("SQLException3: "+ex.getMessage());
		}
		
				
				HttpSession session = req.getSession(); 
				session.setAttribute("nome",nome);
				session.setAttribute("email", email);
				session.setAttribute("loggato","ut");
				res.sendRedirect("Index.jsp");
			
		
		
		
		
		
		
	}
}

}
