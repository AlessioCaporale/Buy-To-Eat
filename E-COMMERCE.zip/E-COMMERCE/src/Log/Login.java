package Log;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class Login extends HttpServlet 
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException,IOException
	{
		String url="jdbc:mysql:///progettopw?autuReconect=true&useSSL=false";
		Connection connect;
		String query;
		PreparedStatement stmt;
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		String email,password;
		String emaild,passd,codf;
		int flag=-1,accesso=0;
		int accessot=0;
		String nome="";
		HttpSession session = req.getSession(); 
		email=req.getParameter("email");
		password=req.getParameter("password");
		try{
			query="SELECT email,pass,nome,codfis,accesso FROM utenti;";
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			connect=DriverManager.getConnection(url,"root","123456789");
			stmt=connect.prepareStatement(query);
			ResultSet ris=stmt.executeQuery();
			while(ris.next())
			{
				
				emaild=ris.getString("email");
				passd=ris.getString("pass");
				codf=ris.getString("codfis");
				accesso=ris.getInt("accesso");
				if(email.equals(emaild) && password.equals(passd))
				{
					session.setAttribute("loggato", "ut");
					session.setAttribute("CDF", codf);
					flag=1;
					nome=ris.getString("nome");
					session.setAttribute("nome",nome);
					session.setAttribute("email",email);
					session.setAttribute("pass", passd);
					accessot=accesso+1;
					
					
				}
				
			}
			stmt.close();
			connect.close();
			if(flag==1)
			{
				String query1;
				Connection connect1;
				PreparedStatement stmt1;
				try{
					query1="UPDATE utenti SET accesso=?,elimina=? WHERE email=?";
					DriverManager.registerDriver(new com.mysql.jdbc.Driver());
					connect1=DriverManager.getConnection(url,"root","123456789");
					stmt1=connect1.prepareStatement(query1);
					stmt1.setInt(1,accessot);
					stmt1.setString(2,"0");
					stmt1.setString(3,(String)(session.getAttribute("email")));
					stmt1.executeUpdate();
					stmt1.close();
					connect1.close();
					
				}catch(SQLException ex)
				{
					System.err.println("SQLException (Aggiornamento): "+ex.getMessage());
				}
				res.sendRedirect("Index.jsp");
			}
			else if(flag==-1)
			{
				//session.setAttribute("loggato", "errore");
				//out.println("Email o Password errati.");
				String query2,nomeaz,idaz;
				Connection connect2;
				PreparedStatement stmt2;
				try{
					query2="SELECT email,pass,nomeaz,ID FROM fornitori WHERE elimina=0";
					DriverManager.registerDriver(new com.mysql.jdbc.Driver());
					connect2=DriverManager.getConnection(url,"root","123456789");
					stmt2=connect2.prepareStatement(query2);
					ResultSet ris2=stmt2.executeQuery();
					while(ris2.next())
					{
						
						emaild=ris2.getString("email");
						passd=ris2.getString("pass");
						nomeaz=ris2.getString("nomeaz");
						idaz=ris2.getString("ID");
						if(email.equals(emaild) && password.equals(passd))
						{
							
							session.setAttribute("loggato", "az");
							session.setAttribute("nomeaz", nomeaz);
							session.setAttribute("emailaz", emaild);
							session.setAttribute("idaz", idaz);
							session.setAttribute("passaz", passd);
							res.sendRedirect("Index.jsp");
							flag=0;
						}
						
					}
					stmt2.close();
					connect2.close();
				}catch(SQLException ex)
				{
					System.err.println("SQLException(Azienda): "+ex.getMessage());
				}
				
			}
			if(flag==-1)
			{
				session.setAttribute("loggato", "errore");
				out.println("<html><head><script>if(confirm('Email o/e Password errati.')){window.open('Index.jsp','_top')}</script></head></html>");
			
			}

			
			
		}catch(SQLException ex)
		{
			System.err.println("SQLException: "+ex.getMessage());
		}
		
		
		
		
	}
}


